% Facts about pets 
pet(fido, dog, 3).
pet(spot, dog, 5).
pet(mittens, cat, 2).
pet(tweety, bird, 1).

% Gender information 
male(fido).
male(spot).
female(mittens).



species(Species, Count) :-
    findall(Name, pet(Name, Species, _), Pets),
    length(Pets, Count).

age_range(MinAge, MaxAge, Count) :-
    findall(Name, (pet(Name, _, Age), Age >= MinAge, Age =< MaxAge), Pets),
    length(Pets, Count).
