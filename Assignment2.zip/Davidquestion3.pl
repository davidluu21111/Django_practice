sum_odd_numbers([], 0).
sum_odd_numbers([First|Rest], Sum) :-
    sum_odd_numbers(Rest, RestSum),
    (   First mod 2 =:= 1
    ->  Sum is First + RestSum
    ;   Sum = RestSum
    ).
